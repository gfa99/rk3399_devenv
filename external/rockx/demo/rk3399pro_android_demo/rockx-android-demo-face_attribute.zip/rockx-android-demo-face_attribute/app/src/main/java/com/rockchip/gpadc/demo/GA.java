package com.rockchip.gpadc.demo;

import java.io.Serializable;

public class GA implements Serializable {

    public int gender;
    public int age;
}
