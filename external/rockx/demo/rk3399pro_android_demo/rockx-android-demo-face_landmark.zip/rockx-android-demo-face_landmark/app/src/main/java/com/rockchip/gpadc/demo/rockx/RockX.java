package com.rockchip.gpadc.demo.rockx;

//import com.rockchip.gpadc.demo.Face;
import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;

import com.rockchip.gpadc.demo.Face;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class RockX {

    private static final String TAG = "rockx";

    private static final int ROCKX_MODULE_FACE_DETECTION = 1;
    private static final int ROCKX_MODULE_FACE_LANDMARK_68 = 2;
    private static final int ROCKX_MODULE_FACE_RECOGITION = 3;
    private static final int ROCKX_MODULE_FACE_ANALYZE = 4;
    private static final int ROCKX_MODULE_OBJECT_DETECTION = 5;
    private static final int ROCKX_MODULE_POSE_BODY = 6;
    private static final int ROCKX_MODULE_POSE_FINGER_21 = 7;
    private static final int ROCKX_MODULE_FACE_LANDMARK_5 = 8;
    private static final int ROCKX_MODULE_HEAD_DETECTION = 9;
    private static final int ROCKX_MODULE_CARPLATE_DETECTION = 10;
    private static final int ROCKX_MODULE_CARPLATE_ALIGN = 11;
    private static final int ROCKX_MODULE_CARPLATE_RECOG = 12;
    private static final int ROCKX_MODULE_OBJECT_TRACK = 13;
    private static final int ROCKX_MODULE_POSE_FINGER_3 = 14;
    private static final int ROCKX_MODULE_FACE_LIVENESS = 15;

    public static final int ROCKX_PIXEL_FORMAT_GRAY8 = 0;
    public static final int ROCKX_PIXEL_FORMAT_RGB888 = 1;
    public static final int ROCKX_PIXEL_FORMAT_BGR888 = 2;

    private String mModelPath;
    private Context mContext;

    private long mRockXFaceDetectionModule;
    private long mRockXFaceLandmarkModule;

    public RockX(Context context) {
        mContext = context;
    }
    public void create() {
        mModelPath = installRockxData(mContext);
        mRockXFaceDetectionModule = native_create_rockx_module(mModelPath, ROCKX_MODULE_FACE_DETECTION);
        mRockXFaceLandmarkModule = native_create_rockx_module(mModelPath, ROCKX_MODULE_FACE_LANDMARK_68);
    }

    private String installRockxData(Context context) {
        File rockxDataDir = new File(context.getFilesDir().getAbsolutePath() + "/rockx-data");
        if (rockxDataDir.exists()) {
            Log.d(TAG, String.format("%s already exist", rockxDataDir.getAbsoluteFile()));
            return rockxDataDir.getAbsolutePath();
        }
        Log.d(TAG, String.format("create %s", rockxDataDir.getAbsoluteFile()));
        rockxDataDir.mkdir();
        AssetManager am = context.getAssets();
        try {
            String rockxDataFileList[] = am.list("rockx-data");
            for (String rockxDataFile : rockxDataFileList) {
                Log.d(TAG, String.format("create %s", rockxDataDir + "/" + rockxDataFile));
                InputStream is = am.open("rockx-data/" + rockxDataFile);
                FileOutputStream fos = new FileOutputStream(rockxDataDir + "/" + rockxDataFile);
                byte[] buffer = new byte[1024];
                int byteCount;
                while ((byteCount = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, byteCount);
                }
                fos.flush();
                is.close();
                fos.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return rockxDataDir.getAbsolutePath();
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        native_destroy_rockx_module(mRockXFaceDetectionModule);
        native_destroy_rockx_module(mRockXFaceLandmarkModule);
    }

    public ArrayList<Face> detectFace(byte[] inData, int inWidth, int inHeight, int inPixelFmt) {
        ArrayList<Face> faceList = new ArrayList<>();
        native_face_detect(mRockXFaceDetectionModule, inData, inWidth, inHeight, inPixelFmt, faceList);
        return faceList;
    }


    public int FaceLanmark(byte[] inData, int inWidth, int inHeight, int inPixelFmt, Face face) {
        int landmark[] = new int[136];

        int box_left = (int)(face.getLocation().left*inWidth);
        int box_top = (int)(face.getLocation().top*inHeight);
        int box_right = (int)(face.getLocation().right*inWidth);
        int box_bottom = (int)(face.getLocation().bottom*inHeight);

        int ret = native_face_lanmark(mRockXFaceLandmarkModule, inData, inWidth, inHeight, inPixelFmt,
                box_left, box_top, box_right, box_bottom,
                landmark);
        if (ret < 0) {
            return ret;
        }

        face.setLandmark(landmark);

        return 0;
    }

    private native long native_create_rockx_module(String modelPath, int module);
    private native void native_destroy_rockx_module(long handle);
    private native int native_face_detect(long handle, byte[] inData, int inWidth, int inHeight, int inPixelFmt, ArrayList<Face> faceList);
    private native int native_face_lanmark(long handle, byte[] inData, int inWidth, int inHeight, int inPixelFmt,
                                             int boxLeft, int boxTop, int boxRight, int boxBottom,
                                             int[] outLandmark);
    static {
        System.loadLibrary("rknn4j");
    }
}
