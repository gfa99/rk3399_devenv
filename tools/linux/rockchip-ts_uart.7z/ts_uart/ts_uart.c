#include "common.h"

/*
*	v1.0 start to use version to manageme the code
*
*
*
*/


int main(int argc, char **argv) {

	int i = 0, rd = 0;
	fd_set readFds;
	int retval;
	struct timeval respTime;
	unsigned char input_buf[bufsize],output_buf[bufsize];
	int size=0;
	int sendsize,sleeptime=0;
	int j,error=0;
//	char md5_chk1[32], md5_chk2[32];
	/* to handle ctrl +c */
	if(signal(SIGINT, signalHandler) == SIG_ERR) {
		printf("ERROR : Failed to register signal handler\n");
		exit(1);
	}

	if (argc != 7 && argc != 8) {
		display_intro();
		exit(1);
	}

	j = sscanf(argv[3],"%li",&ut.baudrate);
  	if (j != 1) 
  		error = 1;	
	j = sscanf(argv[4],"%i",&ut.flow_cntrl);
	if (j != 1) 
		error = 1;
	j = sscanf(argv[5],"%i",&ut.max_delay);
	if (j != 1) 
		error = 1;
	if (!(ut.max_delay >= 0 && ut.max_delay <= 100)) 
		error = 1;
	j = sscanf(argv[6],"%i",&ut.random_enable);
	if (j != 1) 
		error = 1;

	if (error){
		printf("\n Invalid command line argument [argv] \n");
		display_intro();
		exit(1);
	}
	
	if (argv[7] == NULL) {
		ut.fd = open(UART_DEV_NAME, O_RDWR | O_NOCTTY | O_NDELAY | O_NONBLOCK );
        } else {
		ut.fd = open(argv[7], O_RDWR);
	}

	if (ut.fd == -1) {
		printf("open_port: Unable to open port - %s ", UART_DEV_NAME);
		exit(1);
	} else {
		fcntl(ut.fd, F_SETFL, 0);
	}
    
	printf("\n Existing port baud=%d", getbaud(ut.fd));
	/* save current port settings */
	tcgetattr(ut.fd, &oldtio);
	initport(ut.fd, ut.baudrate, ut.flow_cntrl);
	printf("\n Configured port for New baud=%d", getbaud(ut.fd));

	sscanf(argv[1],"%c",&tx_rx);

	switch (tx_rx) {
		
		case 'r':
#if 1
			fd2 = open(argv[2], O_WRONLY | O_CREAT, S_IRWXU | S_IRWXO);
			if (fd2 == -1) {
				printf("\n cannot open %s \n",argv[2]);
				close(ut.fd);
				exit(1);
			}
#endif
			read_flag = 0;
			while(1) {
			 	FD_ZERO(&readFds);
				FD_SET(ut.fd, &readFds);
				respTime.tv_sec =  10;
				respTime.tv_usec = 0;
	
				/* Sleep for command timeout and expect the response to be ready. */
				retval = select(FD_SETSIZE, &readFds, NULL, NULL, &respTime);
				if (retval == 0 ) {
					if (read_flag == 0) {
						printf("\n Waited until timeout; no data was available to read. Exiting... \n");
						if (unlink(argv[2]) == -1)
							printf("\n Failed to delete the file %s \n",argv[2]);
						close_port();
					}
					else {
						//printf("\n select() timed out... waiting for more data\n");
						continue; /*skip this loop because FD_SET doesn't have any data */
					}
				}
				else if (retval == ERROR)
					printf("\n select: error :: %d\n",retval);
	
        		        /* Read data, abort if read fails. */
				if(FD_ISSET(ut.fd, &readFds) != 0)  {
					//fcntl(ut.fd, F_SETFL, FNDELAY);
				    /*	printf("\n entering readport func \n"); */
					if(read_flag == 0) {
						gettimeofday(&ut.start_time, NULL);			
						read_flag = 1;
						printf("\n Reading data from port to file...\n");
					}
					rd = readport(&ut.fd, output_buf);
					if (ERROR == rd) {
						printf("Read Port failed\n");
						close_port();
					}
				}
				if(rd == 0)
					break;
				size += rd;
				i = writeport(&ut.fd, output_buf, rd);
				printf("\n Read %d bytes from port \n",size);
				//printf("\nport returned %d bytes Written %d bytes to output file", rd, i);
				memset(output_buf,0,bufsize);
			}
			gettimeofday(&ut.end_time,NULL);
			printf("\n Read %d bytes from port \n",size);
			FD_CLR(ut.fd, &readFds);	
			break;


		case 's':
			fd1 = open(argv[2],O_RDONLY);
			if(fd1 == -1) {
				printf("\n cannot open %s \n",argv[2]);
				close(ut.fd);
				exit(1);
			}
			gettimeofday(&ut.start_time,NULL);
			printf("\n Sending data from file to port...\n");
			while(1) {
				if (ut.random_enable != 0)
					sendsize = get_rand_value(bufsize);
				else
					sendsize = bufsize;

				rd = read(fd1, &input_buf, sendsize);
				if(rd == 0)
					 break;

				size += rd;
				//printf("\n Read from input file %d bytes \n",rd);
				fcntl(ut.fd, F_SETFL, 0);
				if (!writeport(&ut.fd, input_buf,rd)) {
					printf("\n Writing to port failed\n");
					close_port();
				}
				#ifdef ANDROID_FS
				/* tcdrain not available on ANDROID */
				ioctl(ut.fd, TCSBRK, 1); //equivalent to tcdrain(). perhaps permanent replacement?
				#else
				if(ERROR == tcdrain(ut.fd))
					printf("\n tcdrain failure \n");
				#endif
				memset(input_buf,0,bufsize);

				if (ut.max_delay) {
					sleeptime = get_rand_value(ut.max_delay);
					printf("\n Sleeping for %u seconds...\n",sleeptime);
					sleep(sleeptime); /*sleep for a maximum of X random secs */
					system("echo 1 > /sys/devices/platform/serial8250.0/uart1_rts_toggle");
				}
			}
			gettimeofday(&ut.end_time,NULL);
			printf("\n Written %d bytes to port \n",size);
			/* Wait for 5 seconds for Transmitting to complete before sending the Break sequence */
			sleep(3);
			for(i=0;i<5;i++)
			//printf("\nWriting tcsendbreak()\n");
			tcsendbreak(ut.fd,5);
			break;


		case 'm':
while(1) {		
			//set loopback mode
			int mctrl = TIOCM_LOOP;
			ioctl(ut.fd, TIOCMSET, &mctrl); 
			
			fd1 = open(argv[2], O_RDONLY);
			if(fd1 == -1) {
				printf("\n cannot open %s \n",argv[2]);
				close(ut.fd);
				exit(1);
			}
			gettimeofday(&ut.start_time, NULL);
	
			size = 0;		
			
			printf("\n Sending data from file to port...\n");
			while(1) {
				if (ut.random_enable != 0)
					sendsize = get_rand_value(bufsize);
				else
					sendsize = bufsize;
				
				rd = read(fd1, &input_buf, sendsize);
				if(rd < bufsize) {
					 rd = read(ut.fd, output_buf, bufsize);		
					 if(rd > 0)
					 	printf("leave:%dbyte\n", rd);
					 		
				 	break;
				}
				
				size += rd;
				//printf("\n Read from input file %d bytes \n",rd);
				fcntl(ut.fd, F_SETFL, 0);
				if (!writeport(&ut.fd, input_buf, rd)) {
					printf("\n Writing to port failed\n");
					close_port();
				}
				
				i = 0;
				j = 0;
				while(j < rd) {
					i = read(ut.fd, output_buf + j, rd - j);
					j += i;
					//printf("+++++++count:%d\n", j);
				}
				
				printf("send:%d, receive:%d\n", rd, j);
				i = 0;
				if(j == rd) {
					while(j--) {
						if(output_buf[j] != input_buf[j]) {
							
							//for(i = 0; i < bufsize; i++){
								i = j;
								//printf("position:%d  src:%d but dst:%d\n", j, input_buf[j], output_buf[j]);
							//}
							//break;	
						}
						//if(j == 0)
						//	printf("receive success\n");	
					}
										
				} else {
					printf("send != receive\n");
				}
				
				if(i > 0) {
					printf("+++++++position:%d  src:%02x but dst:%02x\n", i-5, input_buf[i-5], output_buf[i-5]);
					printf("+++++++position:%d  src:%02x but dst:%02x\n", i-4, input_buf[i-4], output_buf[i-4]);
					printf("+++++++position:%d  src:%02x but dst:%02x\n", i-3, input_buf[i-3], output_buf[i-3]);
					printf("+++++++position:%d  src:%02x but dst:%02x\n", i-2, input_buf[i-2], output_buf[i-2]);
					printf("+++++++position:%d  src:%02x but dst:%02x\n", i-1, input_buf[i-1], output_buf[i-1]);
					printf("+++++++position:%d  src:%02x but dst:%02x\n", i, input_buf[i], output_buf[i]);
					printf("+++++++position:%d  src:%02x but dst:%02x\n", i+1, input_buf[i+1], output_buf[i+1]);
					printf("+++++++position:%d  src:%02x but dst:%02x\n", i+2, input_buf[i+2], output_buf[i+2]);
					printf("+++++++position:%d  src:%02x but dst:%02x\n", i+3, input_buf[i+3], output_buf[i+3]);
					printf("+++++++position:%d  src:%02x but dst:%02x\n", i+4, input_buf[i+4], output_buf[i+4]);
					printf("+++++++position:%d  src:%02x but dst:%02x\n", i+5, input_buf[i+5], output_buf[i+5]);
					printf("+++++++position:%d  src:%02x but dst:%02x\n", i+6, input_buf[i+6], output_buf[i+6]);
					
					while(1) {
						sleep(10);
					}
					//close_port();
				}
				memset(input_buf, 0, bufsize);
				memset(output_buf, 0, bufsize);
			}
			close(fd1);
			gettimeofday(&ut.end_time,NULL);
			//printf("\n Written %d bytes to port \n",size);
		}
			break;
	}

	timersub(&ut.end_time,&ut.start_time,&ut.diff_time);
	if(tx_rx == 'r')	
		 ut.diff_time.tv_sec -= 5;
        printf("\n Time taken %08ld sec, %08ld usec\n\n ",ut.diff_time.tv_sec,ut.diff_time.tv_usec);
        /* restore th old port settings. */
	close_port();
	return 0;
}

