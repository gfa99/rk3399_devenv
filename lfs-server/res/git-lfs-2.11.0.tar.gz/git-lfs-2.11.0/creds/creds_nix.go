// +build !windows

package creds

var netrcBasename = ".netrc"
