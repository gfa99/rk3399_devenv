//+build windows
//go:generate goversioninfo

package main
