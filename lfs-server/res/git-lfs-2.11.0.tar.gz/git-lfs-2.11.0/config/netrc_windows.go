// +build windows

package config

var netrcBasename = "_netrc"
